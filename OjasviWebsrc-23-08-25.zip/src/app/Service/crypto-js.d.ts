declare module 'crypto-js';
